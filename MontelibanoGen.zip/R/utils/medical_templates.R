medical_comment_pca <- function (separation_level) 
  if ( separation_level == "hight") {
  "Separación marcada compatible con diferencias biologicas relevantes"
} else {
  "Separación limitada, cambios sutiles"
}